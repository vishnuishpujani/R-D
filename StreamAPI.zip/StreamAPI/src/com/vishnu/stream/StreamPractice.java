package com.vishnu.stream;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.OptionalInt;
import java.util.Random;
import java.util.stream.Collectors;
import java.util.stream.DoubleStream;
import java.util.stream.IntStream;
import java.util.stream.Stream;

public class StreamPractice {
	
	
	public static void main(String[] args) {
		
	/*	
		
		List<Student> list=new ArrayList<>();
		list.add(new Student("vish",22));
		list.add(new Student("rish",22));
		list.add(new Student("visf",22));
		list.add(new Student("virsh",22));
		list.add(new Student("vfish",22));
		list.add(new Student("viseh",22));
		list.add(new Student("vifsh",22));
		
		Stream<Student> parallelStreams=list.parallelStream();
		parallelStreams.forEach(s->doProcess(s));
	}	
	private static void doProcess(Student s) {
		System.out.println(s);
		System.out.println("----------------");*/
		
	Stream<String> build=Stream.<String>	builder().add("vishnu").add("ronaldo").add("messi").build();
	build.forEach(System.out::println);
	
	System.out.println("-----------------");
	Stream<String> limit=Stream.generate(()->"heloo").limit(10);
	limit.forEach(System.out::println);
	System.out.println("-----------------");
	Stream<Integer> limit2=Stream.iterate(10, i->i+2).limit(20);
	limit2.forEach(System.out::println);
	System.out.println("-----------------");
	IntStream range=IntStream.range(1,6);
	range.forEach(System.out::println);
	System.out.println("-----------------");
	IntStream range1=IntStream.rangeClosed(1,6);
	range1.forEach(System.out::println);
	System.out.println("-----------------");
	Random random=new Random();
	DoubleStream doubles=random.doubles(5);
	
	doubles.forEach(System.out::println);
	System.out.println("-----------------");
	IntStream chars="abcd".chars();
	chars.forEach(System.out::println);
	OptionalInt reduced=IntStream.range(1,4).reduce((a,b)->a+b);
    System.out.println(reduced.getAsInt());
    
    System.out.println("--------------------");
    
    int reducedTwoParams=IntStream.range(1, 4).reduce(10, (a,b)->a+b);
    System.out.println(reducedTwoParams);
    
    System.out.println("--------------------");
    
    Integer reduce=Arrays.asList(1,2,3).parallelStream().reduce(10, (a,b)->a+b, (a,b)->{
                 System.out.println("Combiner was called");
                 return a+b;
    });
    
    System.out.println(reduce);

	

//		String arr[]=new String[] {"Aa","bb","cc"};
//		Stream<String> stream=Arrays.stream(arr);
//		stream.forEach(System.out::println);
//			
//		
//		
//		Stream<String> of=Stream.of("Anm","bb","cbc");
//		System.out.println("--------------------------");
//		of.forEach(System.out::println);
//		
//		List<String> list=new ArrayList<>();
//		list.add("vishnu");
//		list.add("nikhil");
//		list.add("kartik");
//		Stream<String> stream2=list.stream();
//		System.out.println("--------------------------");
//		stream2.forEach(System.out::println);
//		
		
		
	}

}
