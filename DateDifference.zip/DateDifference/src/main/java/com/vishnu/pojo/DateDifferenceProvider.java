package com.vishnu.pojo;

public class DateDifferenceProvider {
	private static int DAYS_IN_JAN = 31;
	private static int DAYS_IN_FEB = 28;
	private static int DAYS_IN_MARCH = 31;
	private static int DAYS_IN_APRIL = 30;
	private static int DAYS_IN_MAY = 31;
	private static int DAYS_IN_JUNE = 30;
	private static int DAYS_IN_JULY = 31;
	private static int DAYS_IN_AUG = 31;
	private static int DAYS_IN_SEP = 30;
	private static int DAYS_IN_OCT = 31;
	private static int DAYS_IN_NOV = 30;
	private static int DAYS_IN_DEC = 31;
	private static int difference = 0;

	private static int MONTH[] = { DAYS_IN_JAN, DAYS_IN_FEB, DAYS_IN_MARCH, DAYS_IN_APRIL, DAYS_IN_MAY, DAYS_IN_JUNE,
			DAYS_IN_JULY, DAYS_IN_AUG, DAYS_IN_SEP, DAYS_IN_OCT, DAYS_IN_NOV, DAYS_IN_DEC };

	public static int getDateDifference(MyDate startDate, MyDate endDate) {

		if (sameDate(startDate, endDate) && sameMonth(startDate, endDate) && sameYear(startDate, endDate)) {
			return 0;
		}

		else if (sameMonth(startDate, endDate) && sameYear(startDate, endDate)) {
			return endDate.getDd() - startDate.getDd();
		}

		else if (sameYear(startDate, endDate)) {
			return (remainingDays(startDate) + intervingMonthdays(startDate, endDate) + leadingDays(endDate));
		}

		else {
			return (remainingYearDays(startDate) + intervingYearDays(startDate, endDate) + leadingMonthDays(endDate));
		}

	}

	private static boolean sameDate(MyDate startDate, MyDate endDate) {
		if (startDate.getDd() == endDate.getDd())
			return true;
		return false;
	}

	private static boolean sameMonth(MyDate startDate, MyDate endDate) {
		if (startDate.getMm() == endDate.getMm())
			return true;
		return false;
	}

	private static boolean sameYear(MyDate startDate, MyDate endDate) {
		if (startDate.getYyyy() == endDate.getYyyy())
			return true;
		return false;
	}

	private static int remainingDays(MyDate startDate) {
		int remainingDays = 0;
		if (isLeapYear(startDate) && startDate.getMm() == 2)
			remainingDays = 1;
		remainingDays += MONTH[startDate.getMm() - 1] - startDate.getDd();
		return remainingDays;
	}

	private static int leadingDays(MyDate endDate) {
		return endDate.getDd();
	}

	private static int intervingMonthdays(MyDate startDate, MyDate endDate) {
		int intervingMonthdaysDays = 0;
		if (isLeapYear(startDate) && startDate.getMm() < 2 && endDate.getMm() > 2)
			intervingMonthdaysDays = 1;
		for (int date = startDate.getMm(); date < endDate.getMm() - 1; date++) {
			intervingMonthdaysDays += MONTH[date];
		}
		return intervingMonthdaysDays;
	}

	private static boolean isLeapYear(MyDate startDate) {
		if ((startDate.getYyyy() % 4 == 0 && startDate.getYyyy() % 100 != 0) || startDate.getYyyy() % 400 == 0)
			return true;
		return false;
	}

	private static int remainingYearDays(MyDate startDate) {
		int remainingYearDays = 0;
		int remainDaysInMonth = remainingDays(startDate);
		int intervingMonthdaysDays = intervingMonthdays(startDate, new MyDate(0, 13, startDate.getYyyy()));
		remainingYearDays = remainDaysInMonth + intervingMonthdaysDays;
		return remainingYearDays;
	}

	private static int intervingYearDays(MyDate startDate, MyDate endDate) {
		int intervingYearDaysDays = 0;
		for (int date = startDate.getYyyy() + 1; date < endDate.getYyyy(); date++) {
			if ((date % 4 == 0 && date % 100 != 0) || date % 400 == 0)
				intervingYearDaysDays += 366;
			else
				intervingYearDaysDays += 365;
		}
		return intervingYearDaysDays;
	}

	private static int leadingMonthDays(MyDate endDate) {
		int leadingYearDays = 0;
		int intervingMonthdaysDays = intervingMonthdays(new MyDate(0, 0, endDate.getYyyy()), endDate);
		int leadingDaysInMonth = endDate.getDd();
		leadingYearDays = leadingDaysInMonth + intervingMonthdaysDays;
		return leadingYearDays;
	}

}

//		int day1 = startDate.getDd();
//        int month1 = startDate.getMm();
//        int year1 = startDate.getYyyy();
//
//        int day2 = endDate.getDd();
//        int month2 = endDate.getMm();
//        int year2 = endDate.getYyyy();
//        
//        int days = 0;
//        int daysInYear=0;
//        
//        for (int y = year1+1; y <=year2; y++) {
//               if(y%4==0) 
//                     daysInYear=366+daysInYear;
//               else
//                     daysInYear=365+daysInYear;
//        }
//        for (int i = month1; i < month2; i++) {
//               if (i == 1 || i == 3 || i == 5 || i == 7 || i == 8 || i == 10 || i == 12) {
//                     days = 31 + days;
//               } else if (i == 2)
//                     days = 28 + days;
//               else
//                     days = 30 + days;
//        }
//        // System.out.println(days);
//        days = days - day1 + day2;
//        return days+daysInYear;
//        
//}
