package com.vishnu.lambda;
@FunctionalInterface
public interface MyInterface2  {
 void method2(String name);
}
