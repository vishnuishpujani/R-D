package com.vishnu.lambda;
@FunctionalInterface
public interface Myinterface1 {
public abstract void method1();
}
