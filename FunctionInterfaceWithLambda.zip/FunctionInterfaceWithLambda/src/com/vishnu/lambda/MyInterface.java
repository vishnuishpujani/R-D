package com.vishnu.lambda;
@FunctionalInterface
public interface MyInterface {
public abstract void method1();
}
