package com.vishnu.lambda;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;

public class ClientTest {

	public static void main(String[] args) {
	
		
		Myinterface1 myinterface1=()-> {
			System.out.println("This method Executes using lambdas");};
		myinterface1.method1();
		MyInterface2 myinterface2=(String name)-> {
			System.out.println("This method Executes using lambdas"+name);};
		myinterface2.method2("vishnu");
	}
	
		//createThreadusingAnonymousClass();
		//createThreadUsingLambdaexpressions();
//		List<String> nameList=new ArrayList<>();
//		nameList.add("vishnu");
//		nameList.add("nikhil");
//		nameList.add("karthik");
//		//nameList.forEach((String name)-> {System.out.println(name);});}
//		nameList.forEach(System.out::println);
	
	
	private static void createThreadUsingLambdaexpressions() {
		Runnable r =()->{System.out.println("My task is running");
	};
	Thread thread=new Thread(r);
	thread.start();
}
	/*private static void createThreadUsingAnonymousClass() {	
		Runnable r=new Runnable()
	{
		@Override
		public void run() {
			System.out.println("My task is running");
			
		}
	};
	Thread thread=new Thread(r);
	thread.start();*/
	}

