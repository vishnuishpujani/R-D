package com.vishnu.parking;

public class Customer {

	String customerName;
	String  phoneNo;
	String Time;
	ParkingId id;
	public ParkingId getId() {
		return id;
	}
	public void setId(ParkingId id) {
		this.id = id;
	}
	public Customer(String customerName, String phoneNo, String time) {
		super();
		this.customerName = customerName;
		this.phoneNo = phoneNo;
		Time = time;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getPhoneNo() {
		return phoneNo;
	}
	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}
	public String getTime() {
		return Time;
	}
	public void setTime(String time) {
		Time = time;
	}
	@Override
	public String toString() {
		return "customer [customerName=" + customerName + ", phoneNo=" + phoneNo + ", Time=" + Time + "]";
	}
	
}
