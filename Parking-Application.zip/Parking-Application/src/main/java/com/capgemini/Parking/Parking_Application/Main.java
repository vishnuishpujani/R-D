package com.capgemini.Parking.Parking_Application;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;

import com.vishnu.parking.Customer;
import com.vishnu.parking.ParkingId;

public class Main {

	public static void main(String[] args) {
		Service ser=new Service();
		ser.addCar(new Customer("vishnu","98768879876","6"));
		ser.addCar(new Customer("vishnu","9876887987","6"));
		ser.addCar(new Customer("vishnu","987688796","6"));
		ser.addCar(new Customer("vishnu","987688876","6"));
		Customer customer=new Customer("vishnu","98768879876","6") ;
//		System.out.println(ser.addCar(new Customer("vishnu","98768879876","6")));
//		System.out.println(ser.addCar(new Customer("vishnu","98768879876","6")));
//		System.out.println(ser.addCar(new Customer("vishnu","98768879876","6")));
//		System.out.println(ser.addCar(new Customer("vishnu","98768879876","6")));
//		System.out.println(ser.addCar(new Customer("vishnu","98768879876","6")));
//		System.out.println(ser.addCar(new Customer("vishnu","98768879876","6")));
//		System.out.println(ser.addCar(new Customer("vishnu","98768879876","6")));
//		System.out.println(ser.addCar(new Customer("vishnu","98768879876","6")));
//		System.out.println(ser.addCar(new Customer("vishnu","98768879876","6")));
//		System.out.println(ser.addCar(new Customer("vishnu","98768879876","6")));
		
			ser.addCar(customer);
	for (Map.Entry m :ser.getAllCars() ) {
        System.out.println(m.getKey() + " " + m.getValue());
	}
System.out.println(ser.getCarById(customer.getId()));
	
	

}
}