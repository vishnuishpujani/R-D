package com.capgemini.Parking.Parking_Application;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import com.vishnu.parking.Customer;
import com.vishnu.parking.ParkingId;
import com.vishnu.parking.ParkingId;

public class Service  
{
private static int compartment=1;	
private static int section=1;
private static int floor=1;

Map<ParkingId,Customer> cars;

public Service()
{
	cars=new HashMap();
}
public void addCar(Customer car)
{      
       if(compartment>10)
       {
              section++;
              compartment=1;
              if(section>4)
              {
                    floor++;
                    section=1;
                    compartment=1;
              }
       }
    ParkingId key=new ParkingId(floor,section,compartment);
    
       cars.put(key, car);
       compartment++;
       
       car.setId(key);
}
public Set<Map.Entry<ParkingId,Customer>> getAllCars(){
	return cars.entrySet();
	
}
public Customer getCarById(ParkingId id) {
	return cars.get(id);
}
}
